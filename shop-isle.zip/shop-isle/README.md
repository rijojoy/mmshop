== ShopIsle ==

Images sources:

 * slide1.jpg: https://download.unsplash.com/uploads/141172692104151d94dd4/4f900e54
 * slide2.jpg: https://download.unsplash.com/photo-1434056886845-dac89ffe9b56
 * slide3.jpg: https://download.unsplash.com/reserve/RONyPwknRQOO3ag4xf3R_Kinsey.jpg


 * banner1.jpg: https://download.unsplash.com/photo-1433826672293-6fdc46138e66
 * banner2.jpg: https://download.unsplash.com/photo-1433643667043-663b34a5c052
 * banner3.jpg: https://download.unsplash.com/photo-1435070872030-a8113da23691
 
 * 404.jpg: https://download.unsplash.com/photo-1428895009712-de9e58a18409
 
 * team1.jpg: https://download.unsplash.com/reserve/ysPfhVSzSP2m629CW0mw_selfPortrait.jpg
 * team2.jpg: https://download.unsplash.com/photo-1433615988899-12bdf1bd42b6
 * team3.jpg: https://download.unsplash.com/photo-1427096105551-15e2512fd2dc
 * team4.jpg: https://download.unsplash.com/photo-1434123715472-19686d6cc442
 
 * background-video.jpg https://download.unsplash.com/photo-1436190807865-2e156d40f1a2
 
 * header.jpg: https://download.unsplash.com/photo-1434592370571-b4bacd3377b3

License: All unsplash.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/ 	

ElegantIcons License: GPL 2.0 and MIT http://www.gnu.org/licenses/gpl-2.0.html, http://opensource.org/licenses/MIT

* Bootstrap
Resource URI: http://getbootstrap.com/
Copyright: 2011-2014 Twitter, Inc
License: MIT
License URI: http://opensource.org/licenses/MIT

* OwlCarousel
Copyright: 2013 Bartosz Wojciechowski
Resource URI: http://www.owlgraphic.com/owlcarousel/
License: MIT
License URI: http://opensource.org/licenses/MIT

* SmoothScroll
Copyright: Balazs Galambosi
Resource URI: http://www.owlgraphic.com/owlcarousel/
License: MIT
License URI: http://opensource.org/licenses/MIT

* jquery.mb.YTPlayer
Copyright (c) 2001-2016. Matteo Bicocchi (Pupunzi)
Resource URI: https://github.com/pupunzi/jquery.mb.YTPlayer
Licenses: MIT, GPL
Licenses URI: http://opensource.org/licenses/MIT
              http://www.gnu.org/licenses/gpl.html

* jquery.magnific-popup
Copyright (c) 2013 Dmitry Semenov
Resource URI: http://dimsemenov.com/plugins/magnific-popup/
License: MIT
License URI: http://opensource.org/licenses/MIT

* FlexSlider
Copyright 2012 WooThemes
Resource URI: https://www.woothemes.com/flexslider/
License: MIT
License URI: http://opensource.org/licenses/MIT

* FitVids.js
Copyright 2013, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
Resource URI: http://fitvidsjs.com/
License: WTFPL
License URI: http://sam.zoy.org/wtfpl/

* jqBootstrapValidation
Resource URI: http://ReactiveRaven.github.com/jqBootstrapValidation/
License: MIT
License URI: http://opensource.org/licenses/MIT

* animate.css
Copyright (c) 2013 Daniel Eden
Resource URI: http://daneden.me/animate
License: MIT
License URI: http://opensource.org/licenses/MIT